import re


def word_spans(text):
    return [(m.start(), m.end()) for m in re.finditer(r"\S+", text)]


def window_chunks(text, size=40, overlap=0, offset=0):
    if size <= 0:
        raise ValueError("size must be positive")
    if overlap < 0 or overlap >= size:
        raise ValueError("overlap must be smaller than size")
    spans = word_spans(text)
    if not spans:
        return []
    out = []
    start = 0
    while start < len(spans):
        end = min(start + size, len(spans))
        out.append((spans[start][0] + offset, spans[end - 1][1] + offset))
        if end == len(spans):
            break
        start = end - overlap
    return out


def sentence_spans(text):
    spans = []
    for m in re.finditer(r"[^.!?]+(?:[.!?]+|$)", text):
        s = m.group(0)
        a = m.start() + (len(s) - len(s.lstrip()))
        b = m.start() + len(s.rstrip())
        if b > a:
            spans.append((a, b))
    return spans


def sentence_chunks(text, size=40):
    if size <= 0:
        raise ValueError("size must be positive")
    out = []
    pending = []
    count = 0
    start = None
    end = None
    for a, b in sentence_spans(text):
        n = len(word_spans(text[a:b]))
        if n > size:
            if pending:
                out.append((start, end))
                pending = []
                count = 0
                start = None
                end = None
            for fa, fb in window_chunks(text[a:b], size=size, overlap=0, offset=a):
                out.append((fa, fb))
            continue
        if pending and count + n > size:
            out.append((start, end))
            pending = []
            count = 0
            start = None
            end = None
        if not pending:
            start = a
        pending.append((a, b))
        count += n
        end = b
    if pending:
        out.append((start, end))
    return out


def make_chunks(docs, strategy):
    out = []
    for doc_id, text in docs.items():
        if strategy == "sentence":
            spans = sentence_chunks(text)
        elif strategy == "40-10":
            spans = window_chunks(text, size=40, overlap=10)
        else:
            spans = window_chunks(text, size=40, overlap=0)
        for i, (a, b) in enumerate(spans):
            out.append({"doc_id": doc_id, "chunk_id": f"{doc_id}-{i}", "start": a, "end": b, "text": text[a:b]})
    return out


if __name__ == "__main__":
    try:
        window_chunks("x y", 1, 2)
    except ValueError:
        print("Invalid overlap was rejected.")
    else:
        raise AssertionError("Invalid overlap was accepted")
    short = window_chunks("Reset your password.", size=40, overlap=0)
    print("Short document windows:", short)
    assert len(short) == 1
    long_text = " ".join(["word"] * 95)
    long_windows = window_chunks(long_text, size=40, overlap=0)
    print("95-word sentence windows:", len(long_windows))
    assert len(long_windows) == 3
    long_sentence = " ".join(["word"] * 95) + "."
    fallback = sentence_chunks(long_sentence, size=40)
    print("95-word sentence fallback chunks:", len(fallback))
    assert len(fallback) == 3
    docs = {"example": "Reset your password. Keep recovery codes private."}
    for c in make_chunks(docs, "sentence"):
        print(c["doc_id"], c["start"], c["end"], c["text"])
    print("All chunk checks passed.")
