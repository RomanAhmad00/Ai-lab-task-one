import json

from task2_chunks import make_chunks
from lab6_search import Retriever

if __name__ == "__main__":
    with open("corpus.json", encoding="utf-8") as f:
        corpus = json.load(f)
    engine = Retriever(make_chunks(corpus, "sentence"), "embedding")
    print("Retrieval assistant. Type 'exit' to stop.")
    while True:
        try:
            query = input("Question: ")
        except (EOFError, KeyboardInterrupt):
            print()
            break
        if query.strip().lower() == "exit":
            break
        hits = engine.search(query)
        if not hits:
            print("No candidate evidence; rephrase or contact a human.")
            continue
        print("Candidate evidence; relevance should be checked:")
        for number, (r, score) in enumerate(hits, 1):
            print(number, r["chunk_id"], f"{score:.3f}")
            print(r["text"])
        chosen = input("Choose 1-3 to inspect. Enter 0 if none apply.")
        if not chosen.isdigit() or not 1 <= int(chosen) <= len(hits):
            print("No answer selected. Rephrase or contact a human.")
            continue
        r, score = hits[int(chosen) - 1]
        print(f"Retrieved passage: {r['text']}")
        print(f"Source: {r['doc_id']}, characters {r['start']}-{r['end']}")
