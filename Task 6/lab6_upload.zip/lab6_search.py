from sklearn.feature_extraction.text import TfidfVectorizer


class Retriever:
    def __init__(self, records, backend="tfidf"):
        if not records:
            raise ValueError("Provide nonempty records.")
        for r in records:
            if not r.get("text") or not r["text"].strip():
                raise ValueError("Provide nonempty records.")
        self.records = list(records)
        self.backend = backend
        texts = [r["text"] for r in records]
        if backend == "tfidf":
            self.vectorizer = TfidfVectorizer()
            self.matrix = self.vectorizer.fit_transform(texts)
        elif backend == "embedding":
            from sentence_transformers import SentenceTransformer
            self.model = SentenceTransformer("all-MiniLM-L6-v2", device="cpu")
            self.check_length(texts)
            self.matrix = self.model.encode(texts, normalize_embeddings=True)
        else:
            raise ValueError("Use tfidf or embedding")

    def check_length(self, texts):
        for text in texts:
            ids = self.model.tokenizer(text, truncation=False)["input_ids"]
            if len(ids) > self.model.max_seq_length:
                raise ValueError("Input exceeds encoder token limit.")

    def search(self, query, k=3, filters=None):
        if not query.strip() or k <= 0:
            return []
        if self.backend == "tfidf":
            q = self.vectorizer.transform([query])
            scores = (q @ self.matrix.T).toarray()[0]
        else:
            self.check_length([query])
            q = self.model.encode([query], normalize_embeddings=True)[0]
            scores = q @ self.matrix.T
        allowed = []
        for i, r in enumerate(self.records):
            ok = True
            for key, value in (filters or {}).items():
                if r.get(key) != value:
                    ok = False
            if ok:
                allowed.append(i)
        allowed.sort(key=lambda i: float(scores[i]), reverse=True)
        out = []
        for i in allowed[:k]:
            out.append((self.records[i], float(scores[i])))
        return out


def show_hits(hits):
    if not hits:
        print("No matching records.")
    for record, score in hits:
        print(f"{record['id']}: {score:.3f}")
        print(record["text"])
