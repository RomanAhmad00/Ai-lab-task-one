from sentence_transformers import SentenceTransformer

model = SentenceTransformer("all-MiniLM-L6-v2", device="cpu")
for text in ["Reset a forgotten password.", "I do not need a password reset"]:
    toks = model.tokenizer(text, truncation=False)["input_ids"]
    print("Text:", text)
    print("Tokens:", len(toks), "Limit:", model.max_seq_length, "Fits:", len(toks) <= model.max_seq_length)
