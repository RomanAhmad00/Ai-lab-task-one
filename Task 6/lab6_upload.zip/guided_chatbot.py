from lab6_search import Retriever

FAQ = [
    {"id": "faq:password", "question": "How do I reset my password?", "answer": "Use the recovery link on the login page.", "source": "handbook.txt"},
    {"id": "faq:submit", "question": "Where do I submit my assignment?", "answer": "Use the assignment upload page in the learning portal.", "source": "assessment.txt"},
    {"id": "faq:late", "question": "Can illness justify a late submission?", "answer": "Request an extension with medical evidence before the deadline.", "source": "handbook.txt"},
]


def build_bot(backend="tfidf"):
    records = [dict(r, text=r["question"]) for r in FAQ]
    return Retriever(records, backend=backend)


def reply(engine, query):
    if not query.strip():
        return "No matching FAQ. Please contact the help desk."
    for r in FAQ:
        if query.strip().casefold() == r["question"].casefold():
            return f"{r['answer']} [source: {r['source']}]"
    hits = engine.search(query)
    if not hits:
        return "No matching FAQ. Please contact the help desk."
    lines = []
    for r, score in hits:
        lines.append(f"{r['question']} • {r['source']} (score: {score:.3f})")
    return "\n".join(lines)


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("--backend", choices=["tfidf", "embedding"], default="tfidf")
    args = parser.parse_args()
    engine = build_bot(args.backend)
    print("Retrieval assistant. Type 'exit' to stop.")
    while True:
        try:
            query = input("You: ")
        except (EOFError, KeyboardInterrupt):
            print()
            break
        if query.strip().lower() == "exit":
            break
        print("Bot:", reply(engine, query))
