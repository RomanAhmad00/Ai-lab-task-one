from lab6_search import Retriever, show_hits

records = [
    {"id": "auth:v2", "version": "v2", "text": "Renew an expired API token with POST /v2/token/refresh."},
    {"id": "auth:v1", "version": "v1", "text": "The token field never print its value in logs."},
]

engine = Retriever(records)
show_hits(engine.search("renew expired API token", k=1, filters={"version": "v2"}))
