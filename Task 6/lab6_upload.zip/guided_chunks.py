from task2_chunks import window_chunks, sentence_chunks

text = "Late submission is penalized. Illness may qualify for an extension."
for name, spans in [("word_window", window_chunks(text, size=12, overlap=4)), ("sentence", sentence_chunks(text, size=12))]:
    for start, end in spans:
        print(name, start, end, repr(text[start:end]))
        assert 0 <= start < end <= len(text)
