import csv
import json
import time

import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer

from task2_chunks import make_chunks


def retrieval_metrics(rankings, relevant):
    hits = []
    rr = []
    for ids, good in zip(rankings, relevant):
        ranks = [i for i, x in enumerate(ids[:3], 1) if x in good]
        hits.append(bool(ranks))
        rr.append(1 / ranks[0] if ranks else 0)
    return sum(hits) / len(hits), sum(rr) / len(rr)


def main():
    with open("corpus.json", encoding="utf-8") as f:
        corpus = json.load(f)
    with open("queries.json", encoding="utf-8") as f:
        queries = json.load(f)
    dev = [q for q in queries if q["split"] == "dev" and q["doc"] is not None]
    test = [q for q in queries if q["split"] == "test" and q["doc"] is not None]
    unanswerable = [q for q in queries if q["doc"] is None]
    print("Documents:", len(corpus))
    print("Development queries:", len(dev))
    print("Test queries:", len(test))
    print("Unanswerable queries:", len(unanswerable))
    model = None
    load_seconds = 0.0
    try:
        from sentence_transformers import SentenceTransformer
        t0 = time.perf_counter()
        model = SentenceTransformer("all-MiniLM-L6-v2", device="cpu")
        load_seconds = time.perf_counter() - t0
        print("Model load seconds:", round(load_seconds, 2))
    except Exception as e:
        print("Embedding model could not be loaded:", e)
        print("Embedding configurations are skipped. TF-IDF results below are complete.")
    logs = []
    failures = []
    for strategy in ["40-0", "40-10", "sentence"]:
        chunks = make_chunks(corpus, strategy)
        texts = [c["text"] for c in chunks]
        print()
        print("Strategy:", strategy, "Chunks:", len(chunks))
        for method in ["tfidf", "embedding"]:
            if method == "embedding" and model is None:
                continue
            t0 = time.perf_counter()
            if method == "tfidf":
                vectorizer = TfidfVectorizer()
                matrix = vectorizer.fit_transform(texts)
            else:
                matrix = model.encode(texts, normalize_embeddings=True)
            encode_seconds = time.perf_counter() - t0
            for split, items in [("dev", dev), ("test", test)]:
                rankings = []
                relevant = []
                t0 = time.perf_counter()
                for q in items:
                    if method == "tfidf":
                        qv = vectorizer.transform([q["q"]])
                        scores = (qv @ matrix.T).toarray()[0]
                    else:
                        qv = model.encode([q["q"]], normalize_embeddings=True)[0]
                        scores = qv @ matrix.T
                    top = np.argsort(-scores)[:3]
                    ids = [chunks[i]["chunk_id"] for i in top]
                    good = [c["chunk_id"] for c in chunks if c["doc_id"] == q["doc"] and q["evidence"] in c["text"]]
                    rankings.append(ids)
                    relevant.append(good)
                    print("Query:", q["q"])
                    for rank, i in enumerate(top, 1):
                        print("  ", rank, chunks[i]["chunk_id"], round(float(scores[i]), 3), chunks[i]["doc_id"], chunks[i]["start"], chunks[i]["end"], chunks[i]["text"])
                    ranks = [i for i, x in enumerate(ids[:3], 1) if x in good]
                    hit = bool(ranks)
                    rr = 1 / ranks[0] if ranks else 0
                    if not hit:
                        failures.append((strategy, method, split, q["q"]))
                    logs.append({"strategy": strategy, "method": method, "split": split, "query": q["q"], "doc": q["doc"], "top1": ids[0] if len(ids) > 0 else "", "top2": ids[1] if len(ids) > 1 else "", "top3": ids[2] if len(ids) > 2 else "", "hit": hit, "reciprocal_rank": rr})
                search_seconds = time.perf_counter() - t0
                hit, mrr = retrieval_metrics(rankings, relevant)
                print(strategy, method, split, f"Hit@3={hit:.3f} MRR@3={mrr:.3f}", "encode:", round(encode_seconds, 2), "search:", round(search_seconds, 2))
    print()
    print("Unanswerable queries (no relevant evidence exists):")
    for q in unanswerable:
        print("Query:", q["q"])
    print()
    print("Failures (no relevant chunk in top 3):", len(failures))
    for strategy, method, split, q in failures[:10]:
        print(strategy, method, split, q)
    if not failures:
        print("No failures on answerable queries.")
    with open("retrieval_log.csv", "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(logs[0].keys()))
        writer.writeheader()
        writer.writerows(logs)
    print("Wrote retrieval_log.csv with", len(logs), "rows.")


if __name__ == "__main__":
    main()
