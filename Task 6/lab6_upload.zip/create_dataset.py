import json
from pathlib import Path


corpus = {
    "late": "Late submission is normally penalized. Illness extensions require medical evidence before the deadline.",
    "assignment": "Upload assignments through the learning portal.",
    "submit": "Submit the final file as a PDF.",
    "contractor": "Contractors can work remotely only if the signed contract explicitly permits it.",
    "employee": "Employees can request remote work with manager approval.",
    "printer": "For blank printer pages, check ink levels and run the cleaning utility.",
    "test": "Print a test page afterwards.",
    "auth": "Never share recovery codes.",
    "password": "Reset a forgotten password using the recovery link.",
    "renew": "Renew an expired API token with POST /v2/token/refresh.",
    "version": "Renew an expired API token with POST /v1/token/refresh.",
    "damaged": "For a damaged parcel, contact support within 48 hours.",
    "photographs": "Take clear photographs of the item and packaging.",
}

queries = [
    {"q": "How do I reset my forgotten password?", "doc": "password", "evidence": "Reset a forgotten password using the recovery link.", "split": "dev"},
    {"q": "What is required for illness extensions?", "doc": "late", "evidence": "Illness extensions require medical evidence before the deadline.", "split": "dev"},
    {"q": "How do I submit my assignment?", "doc": "assignment", "evidence": "Upload assignments through the learning portal.", "split": "dev"},
    {"q": "What do I do for blank printer pages?", "doc": "printer", "evidence": "For blank printer pages, check ink levels and run the cleaning utility.", "split": "dev"},
    {"q": "Can contractors work remotely?", "doc": "contractor", "evidence": "Contractors can work remotely only if the signed contract explicitly permits it.", "split": "test"},
    {"q": "How do I renew an expired API token?", "doc": "renew", "evidence": "Renew an expired API token with POST /v2/token/refresh.", "split": "test"},
    {"q": "What do I do for a damaged parcel?", "doc": "damaged", "evidence": "For a damaged parcel, contact support within 48 hours.", "split": "test"},
    {"q": "How can I regain access to my account?", "doc": "password", "evidence": "Reset a forgotten password using the recovery link.", "split": "test"},
    {"q": "Who won the football match?", "doc": None, "evidence": None, "split": "test"},
    {"q": "What are tomorrow's flight prices?", "doc": None, "evidence": None, "split": "test"},
]

if Path("corpus.json").exists():
    raise FileExistsError("Refusing to overwrite corpus.json")
Path("corpus.json").write_text(json.dumps(corpus, ensure_ascii=False, indent=2), encoding="utf-8")
print("Created corpus.json.")
if Path("queries.json").exists():
    raise FileExistsError("Refusing to overwrite queries.json")
Path("queries.json").write_text(json.dumps(queries, ensure_ascii=False, indent=2), encoding="utf-8")
print("Created queries.json.")
