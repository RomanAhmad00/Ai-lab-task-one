# Lab 6: NLP Fundamentals - Tokenization, Embeddings and Text Chunking

## Setup

```
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

The first run of any embedding script downloads the all-MiniLM-L6-v2 model.
The TF-IDF backend needs no model download.

## Shared helper

```
python lab6_search.py
```

## Task 1 - Tokenization and FAQ chatbot

```
python task1_tokens.py
python task1_chatbot_check.py
python guided_chatbot.py
```

## Task 2 - Chunking

```
python task2_chunks.py
```

## Task 3 - Retrieval evaluation (optional bonus)

```
python create_dataset.py
python task3_retrieval.py
python document_chatbot.py
```

## Scenarios

```
python scenario1_handbook.py
python scenario2_support.py
python scenario3_docs.py
python scenario4_workplace.py
python scenario5_equipment.py
```

## Guided examples 6.1 - 6.7

```
python guided_tokens.py
python guided_embeddings.py
python guided_chunks.py
python guided_limits.py
python guided_metrics.py
python guided_chatbot.py
python guided_suggestions.py
```

## Files

- lab6_search.py - shared Retriever helper (TF-IDF and embedding backends)
- task1_tokens.py - whitespace, word-like and model token comparison on eight inputs
- task1_chatbot_check.py - FAQ chatbot checks: exact answer, suggestions, empty and unknown fallback
- task2_chunks.py - word windows, sentence-aware chunking, chunk records
- task3_retrieval.py - retrieval evaluation, Hit@3 and MRR@3, retrieval_log.csv
- document_chatbot.py - interactive retrieval chatbot
- create_dataset.py - creates corpus.json and queries.json
- scenario1_handbook.py to scenario5_equipment.py - the five scenarios
- guided_tokens.py to guided_suggestions.py - guided examples 6.1 to 6.7
