from lab6_search import Retriever, show_hits

records = [
    {"id": "returns:damage", "region": "PK", "text": "For a damaged parcel, contact support within 48 hours."},
    {"id": "returns:photos", "region": "PK", "text": "Take clear photographs of the item and packaging."},
    {"id": "returns:change-mind", "region": "OTHER", "text": "For a change of mind, return unused items within 14 days."},
    {"id": "returns:delivery", "region": "OTHER", "text": "For a change of address, damaged parcel photographs have a 72 hour window."},
]

engine = Retriever(records)
show_hits(engine.search("damaged parcel photographs", k=1, filters={"region": "PK"}))
