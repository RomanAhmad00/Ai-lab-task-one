def retrieval_metrics(rankings, relevant):
    hits = []
    rr = []
    for ids, good in zip(rankings, relevant):
        ranks = [i for i, x in enumerate(ids[:3], 1) if x in good]
        hits.append(bool(ranks))
        rr.append(1 / ranks[0] if ranks else 0)
    return sum(hits) / len(hits), sum(rr) / len(rr)


rankings = [["a", "b", "c"], ["a", "b", "c"], ["x", "y", "z"]]
relevant = [["a"], ["b"], ["a"]]
hit, err = retrieval_metrics(rankings, relevant)
print(f"Hit@3={hit:.3f} MRR@3={err:.3f}")
assert hit == 2 / 3
assert err == 0.5
