import numpy as np
from sentence_transformers import SentenceTransformer

model = SentenceTransformer("all-MiniLM-L6-v2", device="cpu")
passages = ["Reset a forgotten password using the recovery link.", "Check ink levels when a printer produces blank pages.", "I do not need a password reset"]
c = model.encode(passages, normalize_embeddings=True)
q = model.encode(["How can I recover my login?"], normalize_embeddings=True)[0]
scores = q @ c.T
print("Embedding shape:", c.shape)
for i, s in enumerate(scores):
    print(i, round(float(s), 3), passages[i])
assert np.allclose(np.linalg.norm(c, axis=1), 1, atol=1e-5)
print("Top passage:", passages[int(np.argmax(scores))])
