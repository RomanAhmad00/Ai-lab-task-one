from guided_chatbot import build_bot

engine = build_bot()
query = "How do I submit my assignment?"
print("Suggested questions:")
for record, score in engine.search(query, k=3):
    if score > 0:
        print(f"{record['question']} • {score:.3f}")
