import re

inputs = [
    "I can't submit CS4944 late!",
    "help@example.com",
    "",
    "میں یونیورسٹی جا رہا ہوں",
    "CS4944 version 2.1",
    "AI search",
]

for text in inputs:
    words = re.findall(r"\w+", text, flags=re.UNICODE)
    print("Original:", repr(text))
    print("Whitespace:", text.split(), len(text.split()))
    print("Word-like:", words, len(words))
    print()
