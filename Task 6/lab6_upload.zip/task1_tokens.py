import re

from sentence_transformers import SentenceTransformer

texts = [
    "Hello, world!",
    "I can't submit CS4944 late!",
    "help@example.com",
    "CS4944",
    "",
    "یہ ایک اردو جملہ ہے",
    "AI search",
    "CS4944 version 2.1",
]

for text in texts:
    words = text.split()
    parts = re.findall(r"\w+", text, flags=re.UNICODE)
    print(repr(text))
    print("Whitespace:", words, len(words))
    print("Word-like:", parts, len(parts))
    print()

model = SentenceTransformer("all-MiniLM-L6-v2", device="cpu")
for text in texts[:2]:
    ids = model.tokenizer(text)["input_ids"]
    print(repr(text))
    print("Model tokens:", len(ids))
    print("Model token ids:", ids)
