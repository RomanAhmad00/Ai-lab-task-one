from guided_chatbot import build_bot, reply

engine = build_bot()
answer = reply(engine, "How do I reset my password?")
print(answer)
assert "Use the recovery link" in answer
suggest = reply(engine, "password recovery")
print(suggest)
assert "How do I reset my password?" in suggest
empty = reply(engine, "")
print(empty)
assert "Please contact the help desk" in empty
unknown = reply(engine, "Who won the football match?")
print(unknown)
assert "How do I reset my password?" in unknown
assert "Use the recovery link" not in unknown
print("All Task 1 chatbot checks passed.")
